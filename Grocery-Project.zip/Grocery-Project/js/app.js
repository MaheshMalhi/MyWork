$(document).ready(function(){
    
     
      
        $('.food-slider').slick( { 
            infinite:true,  
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows:true,
            autoplay:true,
            autoplaySpeed:2000,
            dots:false,
            
           
            
      

});
});







const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
    container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
});

function display_alert()
 {
 alert("Successfully");
 }


 function addToCart()
 {
 alert("Please provide your details?");
 }